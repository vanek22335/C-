﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define COUNT 10 // Количество строк
#define MAX_STRING_SIZE 20 // Максимальная длина строки

// Функция сравнения строк в лексикографическом порядке с учетом регистра
int compareLexicographic(const void* a, const void* b) {
    return strcmp((const char*)a, (const char*)b);
}

// Функция сравнения строк в лексикографическом порядке без учета регистра
int compareLexicographicIgnoreCase(const void* a, const void* b) {
    return strcasecmp((const char*)a, (const char*)b);
}

// Функция сравнения строк по длине
int compareLength(const void* a, const void* b) {
    size_t len1 = strlen((const char*)a);
    size_t len2 = strlen((const char*)b);
    return len1 - len2;
}

// Функция сравнения строк по длине в обратном порядке
int compareLengthReverse(const void* a, const void* b) {
    return compareLength(b, a);
}

int main() {
    // Создание статического двумерного массива
    char staticArray[COUNT][MAX_STRING_SIZE] = { 0 };

    // Создание динамического одномерного массива
    char** dynamicArray = (char**)malloc(COUNT * sizeof(char*));
    for (int i = 0; i < COUNT; i++) {
        dynamicArray[i] = (char*)malloc(MAX_STRING_SIZE * sizeof(char));
        memset(dynamicArray[i], 0, MAX_STRING_SIZE);
    }

    // Чтение строк из файла и размещение их в массивах
    FILE* inputFile = fopen("strings.txt", "r");
    char line[MAX_STRING_SIZE];
    int i = 0; // Индекс текущей строки
    while (fgets(line, sizeof(line), inputFile) != NULL && i < COUNT) {
        size_t lineLength = strlen(line);
        if (line[lineLength - 1] == '\n') {
            line[lineLength - 1] = '\0';
            lineLength--;
        }

        if (lineLength <= MAX_STRING_SIZE) {
            // Строка помещается в статический массив полностью
            strcpy(staticArray[i], line);
        }
        else {
            // Часть строки помещается в статический массив
            strncpy(staticArray[i], line, MAX_STRING_SIZE - 1);

            // Остальная часть строки помещается в динамический массив
            strcpy(dynamicArray[i], line + MAX_STRING_SIZE - 1);
        }
        i++;
    }
    fclose(inputFile);

    // Сортировка строк, используя функцию сравнения compareLexicographic
    qsort(staticArray, COUNT, sizeof(staticArray[0]), compareLexicographic);
    qsort(dynamicArray, COUNT, sizeof(dynamicArray[0]), compareLexicographic);

    // Вывод отсортированных строк
    printf("Sorted strings:\n");
    for (int i = 0; i < COUNT; i++) {
        printf("%s%s\n", staticArray[i], dynamicArray[i]);
    }

    // Освобождение памяти, выделенной для динамического массива
    for (int i = 0; i < COUNT; i++) {
        free(dynamicArray[i]);
    }
    free(dynamicArray);

    return 0;
}